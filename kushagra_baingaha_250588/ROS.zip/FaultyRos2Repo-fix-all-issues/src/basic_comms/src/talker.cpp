#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

// BUG 1: Timer period is 0ms — node starts but never publishes anything
// BUG 2: Topic name is "/chatter" — listener is subscribed to "/chattar" (typo)

class Talker : public rclcpp::Node
{
public:
  Talker() : Node("talker"), count_(0)
  {
    publisher_ = this->create_publisher<std_msgs::msg::String>("/chatter", 10);

    // Timer fires every 0 milliseconds — effectively never scheduled correctly
    timer_ = this->create_wall_timer(
      std::chrono::milliseconds(500),
      std::bind(&Talker::publish_message, this)
    );

    RCLCPP_INFO(this->get_logger(), "Talker node started.");
  }

private:
  void publish_message()
  {
    auto message = std_msgs::msg::String();
    message.data = "Hello ROS2! Count: " + std::to_string(count_++);
    RCLCPP_INFO(this->get_logger(), "Publishing: '%s'", message.data.c_str());
    publisher_->publish(message);
  }

  rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;
  rclcpp::TimerBase::SharedPtr timer_;
  size_t count_;
};

int main(int argc, char * argv[])
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<Talker>());
  rclcpp::shutdown();
  return 0;
}

# basic_comms

A ROS2 package for robot communication.

## What it does

There is a talker node and a listener node. The talker sends messages. The listener receives them.

## Requirements

- ROS2 (tested on Humble)
- colcon

## Notes

- Something might not work. Check the code.
- Launch file is in the `launch/` folder.
- Good luck.

## Build instructions

 # Clone the repository
git clone https://github.com/YOUR_USERNAME/FaultyRos2Repo
cd FaultyRos2Repo

 # Build the package
colcon build --packages-select basic_comms

 # Source the workspace
source install/setup.bash

## Run Instructions

 #Option 1

ros2 launch basic_comms comms.launch.py

 #Option 2 (in separate terminal)

ros2 run basic_comms talker

ros2 run basic_comms listener

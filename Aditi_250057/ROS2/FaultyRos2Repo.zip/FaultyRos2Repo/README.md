# basic_comms

A ROS2 package for robot communication.

## What it does

There is a talker node and a listener node. The talker sends messages. The listener receives them.

## Requirements

- ROS2 (tested on Humble)
- colcon

## Notes

- Something might not work. Check the code.
- Launch file is in the `launch/` folder.
- Good luck.
## How to Build and Run

### Step 1: Build the workspace
Navigate to your ROS2 workspace root folder and build the package:
colcon build --packages-select basic_comms

### Step 2: Source the environment
Open a new terminal window, navigate to your workspace, and source the setup file:
source install/setup.bash

### Step 3: Launch the nodes
Run the launch file to start both the talker and listener nodes:
ros2 launch basic_comms comms.launch.py

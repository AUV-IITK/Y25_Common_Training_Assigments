from launch import LaunchDescription
from launch_ros.actions import Node


def generate_launch_description():
    return LaunchDescription([

        # BUG 6: executable name is "talkers" — should be "talker"
        # This will cause the launch to fail with "executable not found"
        Node(
            package='basic_comms',
            executable='talkers',
            name='talker',
            output='screen',
        ),

        Node(
            package='basic_comms',
            executable='listener',
            name='listener',
            output='screen',
        ),
    ])

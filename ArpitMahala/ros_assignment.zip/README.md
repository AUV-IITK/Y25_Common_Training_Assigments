# basic_comms

A ROS2 package for robot communication.

## What it does

There is a talker node and a listener node. The talker sends messages. The listener receives them.

## Requirements

- ROS2 (tested on Humble)
- colcon

To build this package, navigate to the root of your ROS2 workspace and run the following command:

```bash
colcon build --packages-select basic_comms
